This is a collection of gallery art for the game BLUE REVOLVER, available for PC/OSX/Linux: http://bluerevolvergame.com

By playing the game, clearing missions or attempting full clears, you can gradually unlock most of these gallery pieces. These are supplied for use as wallpaper etc.

Guest artists are:
Shiomachi
Raigou
Yosuke
Arsk
Hermes
Naso
Mandi
Ken
Moudoku
U#
Yawe
Rog Rockbe

All other art created by woof.

All art is (c) Stellar Circle and respective artists. Art is provided for personal use only, please do not redistribute.